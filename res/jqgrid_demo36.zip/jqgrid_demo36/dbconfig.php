<?php
$dbhost     = 'localhost';
$dbuser     = 't3vidofon';
$dbpassword = 't3vidofon';
$database   = 't3vidofon';

?>
